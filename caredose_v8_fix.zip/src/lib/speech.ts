// src/lib/speech.ts - STABLE voice assistant with freeze prevention
class SpeechService {
  private synthesis: SpeechSynthesis | null = null;
  private voices: SpeechSynthesisVoice[] = [];
  private preferredVoice: SpeechSynthesisVoice | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.synthesis = window.speechSynthesis;
      if (this.synthesis) {
        const loadVoices = () => {
          this.voices = this.synthesis!.getVoices();
          this.setPreferredVoice();
        };
        if (this.synthesis.getVoices().length > 0) loadVoices();
        else this.synthesis.addEventListener('voiceschanged', loadVoices);
      }
    }
  }

  private setPreferredVoice() {
    this.preferredVoice = this.voices.find(v =>
      (v.name.includes('Google UK') || v.name.includes('Samantha') ||
       v.name.includes('Female') || v.name.includes('Moira') ||
       v.name.includes('Tessa') || v.name.includes('Zira')) &&
      v.lang.startsWith('en')
    ) || this.voices.find(v =>
      (v.name.includes('Google') || v.name.includes('Microsoft')) && v.lang.startsWith('en')
    ) || this.voices[0] || null;
  }

  speak(text: string, rate: number = 0.85, pitch: number = 1.1): Promise<void> {
    return new Promise((resolve) => {
      if (!this.synthesis) { resolve(); return; }
      this.synthesis.cancel();
      setTimeout(() => {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = rate;
        utterance.pitch = pitch;
        utterance.volume = 1;
        utterance.lang = 'en-US';
        if (this.preferredVoice) utterance.voice = this.preferredVoice;
        const timeout = setTimeout(() => { resolve(); }, (text.length / 10) * 1000 + 3000);
        utterance.onend = () => { clearTimeout(timeout); resolve(); };
        utterance.onerror = () => { clearTimeout(timeout); resolve(); };
        this.synthesis!.speak(utterance);
      }, 100);
    });
  }

  private createFreshRecognition(): any {
    const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (!SpeechRecognition) return null;
    const rec = new SpeechRecognition();
    rec.continuous = false;
    rec.interimResults = false;
    rec.lang = 'en-US';
    rec.maxAlternatives = 3;
    return rec;
  }

  listenForResponse(timeoutMs: number = 8000): Promise<string> {
    return new Promise((resolve) => {
      const rec = this.createFreshRecognition();
      if (!rec) { resolve('not_supported'); return; }
      let resolved = false;
      let timer: ReturnType<typeof setTimeout> | null = null;
      const done = (result: string) => {
        if (resolved) return;
        resolved = true;
        if (timer) clearTimeout(timer);
        try { rec.stop(); } catch {}
        try { rec.abort(); } catch {}
        rec.onresult = null;
        rec.onerror = null;
        rec.onend = null;
        rec.onnomatch = null;
        setTimeout(() => resolve(result), 200);
      };
      timer = setTimeout(() => done('timeout'), timeoutMs);
      rec.onresult = (event: any) => {
        const results: string[] = [];
        for (let i = 0; i < event.results.length; i++) {
          results.push(event.results[i][0].transcript.toLowerCase().trim());
        }
        done(results.join(' '));
      };
      rec.onerror = (event: any) => {
        if (event.error === 'not-allowed') done('permission_denied');
        else if (event.error === 'no-speech') done('timeout');
        else done('error');
      };
      rec.onend = () => { if (!resolved) done('timeout'); };
      rec.onnomatch = () => done('timeout');
      try { rec.start(); } catch (e) { done('error'); }
    });
  }

  async askQuestion(prompt: string, timeoutMs: number = 8000): Promise<{ text: string; error?: string }> {
    await this.speak(prompt);
    await new Promise(r => setTimeout(r, 400));
    const result = await this.listenForResponse(timeoutMs);
    if (result === 'not_supported') return { text: '', error: 'Speech recognition not supported in this browser.' };
    if (result === 'permission_denied') return { text: '', error: 'Microphone permission denied.' };
    if (result === 'timeout' || result === 'error') return { text: '', error: 'I did not catch that.' };
    return { text: result };
  }

  processQuery(query: string): string {
    const lq = query.toLowerCase().trim();
    if (!lq) return 'unknown';
    if (lq.includes('fall') || lq.includes('fell') || lq.includes('fallen')) return 'emergency_fall';
    if (lq.includes('chest pain') || lq.includes('heart attack')) return 'emergency_pain';
    if (lq.includes('confusion') || lq.includes('confused') || lq.includes('dizzy')) return 'emergency_confusion';
    if (lq.includes('emergency') || lq.includes('help me') || lq.includes('sos')) return 'emergency';
    if (lq.includes('call caregiver') || lq.includes('call my caregiver') || lq.includes('call nurse')) return 'call_caregiver';
    if (lq.includes('call doctor') || lq.includes('call my doctor')) return 'call_doctor';
    if (lq.includes('call 911') || lq.includes('call ambulance')) return 'call_911';
    if (lq.includes('next medicine') || lq.includes('next dose') || lq.includes('next pill')) return 'next_medicine';
    if (lq.includes('take medicine') || lq.includes('took my') || lq.includes('mark taken') || lq.includes('i took')) return 'mark_taken';
    if (lq.includes('skip') && !lq.includes('skip reminder')) return 'mark_skipped';
    if (lq.includes('missed') && (lq.includes('dose') || lq.includes('medicine'))) return 'missed_medicines';
    if (lq.includes('all medicines') || lq.includes('my medicines') || lq.includes('medicine list') || lq.includes('list medicines')) return 'list_medicines';
    if (lq.includes('medicine') || lq.includes('pill') || lq.includes('tablet') || lq.includes('medication')) return 'today_schedule';
    if (lq.includes('schedule') || lq.includes('timetable')) return 'read_schedule';
    if (lq.includes('appointment') || lq.includes('doctor visit')) return 'next_appointment';
    if (lq.includes('caregiver') || lq.includes('nurse')) return 'caregiver_info';
    if (lq.includes('wellness') || lq.includes('health score') || lq.includes('my score')) return 'wellness_score';
    if (lq.includes('adherence') || lq.includes('compliance')) return 'adherence_rate';
    if (lq.includes('time') && !lq.includes('medicine')) return 'current_time';
    if (lq.includes('date') || lq.includes('today is') || lq.includes('what day')) return 'current_date';
    if (lq.includes('remind') || lq.includes('reminder')) return 'set_reminder';
    if (lq.includes('hello') || lq.includes('hi') || lq.includes('hey') || lq.includes('good morning') || lq.includes('good afternoon') || lq.includes('good evening')) return 'greeting';
    if (lq.includes('thank') || lq.includes('thanks')) return 'thanks';
    if (lq.includes('bye') || lq.includes('goodbye') || lq.includes('see you')) return 'goodbye';
    if (lq.includes('how are you')) return 'how_are_you';
    if (lq.includes('help') || lq.includes('what can you do') || lq.includes('commands')) return 'help';
    if (lq.includes('refill') || lq.includes('running out') || lq.includes('low stock')) return 'refill_reminder';
    if (lq.includes('instruction') || lq.includes('how to take')) return 'medicine_instructions';
    if (lq.includes('side effect')) return 'side_effects';
    if (lq.includes('blood pressure') || lq.includes('pressure')) return 'health_tip_bp';
    if (lq.includes('blood sugar') || lq.includes('sugar') || lq.includes('diabetes')) return 'health_tip_sugar';
    if (lq.includes('water') || lq.includes('drink') || lq.includes('hydrat')) return 'health_tip_water';
    if (lq.includes('exercise') || lq.includes('walk') || lq.includes('physio')) return 'health_tip_exercise';
    if (lq.includes('sleep') || lq.includes('rest') || lq.includes('tired')) return 'health_tip_sleep';
    return 'unknown';
  }

  async handleIntent(intent: string, context: any): Promise<string> {
    const hour = new Date().getHours();
    const greetingWord = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
    const firstName = context.profileName?.split(' ')[0] || 'there';

    switch (intent) {
      case 'greeting': return `${greetingWord} ${firstName}! I'm your health assistant. How can I help you today?`;
      case 'thanks': return `You're welcome, ${firstName}! Is there anything else I can help you with?`;
      case 'goodbye': return `Take care, ${firstName}! Remember to take your medicines on time. Goodbye!`;
      case 'how_are_you': return `I'm doing great and ready to help you, ${firstName}! How are you feeling today?`;
      case 'next_medicine':
        if (context.nextDose) {
          let resp = `Your next medicine is ${context.nextDose.name}, ${context.nextDose.dosage}, at ${context.nextDose.time}.`;
          if (context.nextDose.foodTiming) resp += ` Take it ${context.nextDose.foodTiming} food.`;
          if (context.nextDose.instructions) resp += ` ${context.nextDose.instructions}`;
          return resp;
        }
        return 'You have no upcoming medicines scheduled. All done for today!';
      case 'list_medicines':
      case 'today_schedule':
        if (context.medicines?.length > 0) {
          const pending = context.medicines.filter((m: any) => !m.taken);
          const taken = context.medicines.filter((m: any) => m.taken);
          let resp = `You have ${context.medicines.length} medicines today. ${taken.length} taken, ${pending.length} remaining.`;
          if (pending.length > 0) resp += ` Remaining: ${pending.slice(0, 3).map((m: any) => m.name).join(', ')}.`;
          return resp;
        }
        return 'You have no medicines scheduled for today.';
      case 'missed_medicines':
        if (context.missedDoses?.length > 0) {
          const missed = context.medicines?.filter((m: any) => context.missedDoses.includes(m.id)).map((m: any) => m.name).join(', ') || 'some doses';
          return `You have ${context.missedDoses.length} missed dose(s) today: ${missed}. Please take them if not too late, or contact your doctor.`;
        }
        return "You haven't missed any medicines today. Great job!";
      case 'read_schedule':
        if (context.medicines?.length > 0) {
          let msg = 'Here is your medicine schedule. ';
          context.medicines.forEach((m: any) => { if (m.schedule?.length > 0) msg += `${m.name}, ${m.dosage}, at ${m.schedule.join(' and ')}. `; });
          return msg;
        }
        return 'No medicines scheduled today.';
      case 'medicine_instructions':
        if (context.nextDose) {
          let inst = `For ${context.nextDose.name}: take ${context.nextDose.dosage}`;
          if (context.nextDose.foodTiming) inst += ` ${context.nextDose.foodTiming} food`;
          if (context.nextDose.instructions) inst += `. ${context.nextDose.instructions}`;
          return inst + '.';
        }
        return 'Please check your medicine schedule for instructions on each medicine.';
      case 'next_appointment':
        if (context.appointments?.length > 0) {
          const appt = context.appointments[0];
          const dateStr = new Date(appt.date).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
          return `Your next appointment is on ${dateStr} at ${appt.time}${appt.doctor ? ` with Dr. ${appt.doctor}` : ''}${appt.location ? ` at ${appt.location}` : ''}.`;
        }
        return 'You have no upcoming appointments scheduled.';
      case 'caregiver_info':
        if (context.caregivers?.length > 0) {
          const names = context.caregivers.map((c: any) => c.name).join(', ');
          return `You have ${context.caregivers.length} caregiver${context.caregivers.length > 1 ? 's' : ''}: ${names}. Say "call caregiver" to call them.`;
        }
        return 'You have no caregivers connected yet.';
      case 'call_caregiver':
        if (context.caregivers?.length > 0) return `CALL_CAREGIVER:${context.caregivers[0].name}`;
        return 'You have no caregivers connected to call.';
      case 'call_doctor': return 'CALL_DOCTOR';
      case 'call_911': return 'CALL_911';
      case 'mark_taken':
        if (context.nextDose) return `MARK_TAKEN:${context.nextDose.name}`;
        return 'Which medicine did you take? Please use the medicine list to mark it.';
      case 'mark_skipped':
        if (context.nextDose) return `MARK_SKIPPED:${context.nextDose.name}`;
        return 'Which medicine did you skip? Please check your medicine list.';
      case 'wellness_score': {
        const score = context.wellnessScore || 0;
        const level = score >= 80 ? 'excellent' : score >= 60 ? 'good' : score >= 40 ? 'fair' : 'needs attention';
        return `Your wellness score is ${score} out of 100, which is ${level}.`;
      }
      case 'adherence_rate': {
        const rate = context.adherenceRate || 0;
        return `Your medicine adherence rate is ${rate}%. ${rate >= 90 ? 'Excellent!' : rate >= 70 ? 'Good job. Try to improve.' : 'Needs improvement. Please try not to miss doses.'}`;
      }
      case 'refill_reminder': return "Please contact your doctor or pharmacy soon for a refill.";
      case 'emergency': return 'EMERGENCY_MODAL';
      case 'emergency_fall': return 'EMERGENCY_FALL';
      case 'emergency_pain': return 'EMERGENCY_PAIN';
      case 'emergency_confusion': return 'EMERGENCY_CONFUSION';
      case 'current_time': return `The current time is ${new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}.`;
      case 'current_date': return `Today is ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.`;
      case 'health_tip_water': return 'Try to drink at least 6 to 8 glasses of water daily. Hydration helps your medicines work better!';
      case 'health_tip_bp': return 'To manage blood pressure: take your medicines regularly, reduce salt intake, and exercise gently.';
      case 'health_tip_sugar': return 'For blood sugar: take your medicines on time, eat regular balanced meals, and avoid sugary drinks.';
      case 'health_tip_exercise': return 'Light exercise like walking for 20 to 30 minutes daily is great for your health.';
      case 'health_tip_sleep': return 'Try to sleep 7 to 8 hours. Keep a regular sleep schedule for better health.';
      case 'set_reminder': return "Your medicine reminders are set automatically. I will notify you when it is time.";
      case 'side_effects': return "Please ask your doctor or pharmacist about potential side effects of your specific medicines.";
      case 'help': return 'I can help with: medicines, next dose, appointments, wellness score, caregivers, and emergencies. Just ask!';
      default: return "I'm here to help! Ask me about your medicines, appointments, or say \"help\" to hear all my commands.";
    }
  }

  async remindWithConfirmation(medicineName: string, dosage: string): Promise<'taken' | 'snooze' | 'skip' | 'no-response'> {
    await this.speak(`Hello! It's time to take your medicine: ${medicineName}, ${dosage}. Please take it now.`);
    await new Promise(resolve => setTimeout(resolve, 2000));
    await this.speak('Have you taken your medicine? Please say yes, snooze, or skip.');
    const response = await this.listenForResponse(10000);
    if (response.includes('yes') || response.includes('taken') || response.includes('took')) {
      await this.speak('Thank you for taking your medicine. Stay healthy!');
      return 'taken';
    } else if (response.includes('snooze') || response.includes('later')) {
      await this.speak("I'll remind you again in 10 minutes.");
      return 'snooze';
    } else if (response.includes('skip')) {
      await this.speak("I'll mark this dose as skipped.");
      return 'skip';
    }
    return 'no-response';
  }

  remind(medicineName: string, dosage: string) {
    return this.speak(`Hello! It's time to take your medicine: ${medicineName}, ${dosage}. Please take it now.`);
  }

  stopSpeaking() { if (this.synthesis) this.synthesis.cancel(); }
  isSpeaking(): boolean { return this.synthesis ? this.synthesis.speaking : false; }
}

export const speechService = new SpeechService();
